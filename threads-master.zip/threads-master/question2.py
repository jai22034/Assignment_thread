from threading import *
import time
for count in range(1,11):
    print (count)
    time.sleep(1)